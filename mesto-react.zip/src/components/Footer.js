import React from "react";
function Footer (){
    return(
        <footer className="footer">
				<div className="container">
					<p className="footer__copyright">&copy;2022 Mesto Russia</p>
				</div>
			</footer>
    );
}
export default Footer;